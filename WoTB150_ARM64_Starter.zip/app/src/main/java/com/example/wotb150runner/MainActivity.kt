package com.example.wotb150runner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var selectedPath: TextView
    private val pickApkRequest = 1501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterImmersiveMode()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "WoTB 1.5 Runner"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "ARM64 host • ARMv7 target • QEMU runtime prototype"
            textSize = 14f
            setTextColor(0xFFB8C7D9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        val choose = Button(this).apply {
            text = "Pick APK File"
            setOnClickListener { pickApk() }
        }
        selectedPath = TextView(this).apply {
            text = "No APK selected"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 16, 0, 16)
            gravity = Gravity.CENTER
        }
        val run = Button(this).apply {
            text = "Prepare / Run"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Prototype stage: APK selection works; the ARMv7 Android/QEMU runtime is not integrated yet.",
                    Toast.LENGTH_LONG
                ).show()
                status.text = "APK selected. Runtime integration is the next milestone; this build does not launch the game yet."
            }
        }
        status = TextView(this).apply {
            text = "Milestone 1: launcher and APK picker."
            textSize = 14f
            setTextColor(0xFFFFD166.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }

        page.addView(title)
        page.addView(subtitle)
        page.addView(choose)
        page.addView(selectedPath)
        page.addView(run)
        page.addView(status)

        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun pickApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, pickApkRequest)
    }

    @Deprecated("Uses the compatible Activity result API for a minimal starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickApkRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val folder = File(getExternalFilesDir(null), "selected-apks").apply { mkdirs() }
            val output = File(folder, "selected-${System.currentTimeMillis()}.apk")
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Could not open selected file" }
                FileOutputStream(output).use { out -> input.copyTo(out) }
            }
            selectedPath.text = "Selected APK copied to app storage:\n${output.absolutePath}\nSize: ${output.length() / 1024} KB"
            status.text = "APK stored persistently in app-specific storage. Not launched yet."
        } catch (e: Exception) {
            status.text = "Could not copy APK: ${e.message}"
        }
    }

    private fun enterImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }
}
