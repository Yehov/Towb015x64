# WoTB 1.5 Runner — starter milestone

This is the first buildable Android project for the ARM64-only host target.

## What this milestone does
- Opens in immersive landscape mode.
- Provides a **Pick APK File** button.
- Copies the selected APK into persistent app-specific storage.
- Can be built in GitHub Actions without a PC.
- Produces a debug APK artifact.

## What it does NOT do yet
This is not an emulator yet. It does not execute the selected APK or start WoT Blitz. QEMU alone is not enough: a working solution also needs an Android compatibility/runtime layer, JNI and Android system-service support, and graphics/audio integration. The next milestone is to add and validate the ARMv7 execution backend and inspect the target game's native-library requirements.

## Build from a phone with GitHub Actions
1. Create a repository on GitHub.
2. Upload the contents of this ZIP (not the ZIP itself) into the repository.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open its run, scroll to **Artifacts**, and download `WoTB150-Runner-debug`.
6. Extract the artifact ZIP and install `app-debug.apk` on the Android phone.

## Project choices
- Package: `com.example.wotb150runner`
- Minimum Android version: Android 8.0 (API 26)
- Landscape immersive UI
- The app keeps selected APK copies under its app-specific external-files directory.
- No game APK or copyrighted game assets are bundled.
